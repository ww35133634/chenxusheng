#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Date: 2018/4/14

print("111111")

